function toggleReadMore() {
    var moreText = document.querySelector('.more');
    var buttonText = document.querySelector('button');
    if (moreText.style.display === 'none') {
      moreText.style.display = 'block';
      buttonText.innerHTML = 'Read Less';
    } else {
      moreText.style.display = 'none';
      buttonText.innerHTML = 'Read More';
    }
  } 